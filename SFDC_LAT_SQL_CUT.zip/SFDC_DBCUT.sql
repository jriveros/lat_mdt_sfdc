--File1 to Generate the Schema on PublicSchema.
@@SFDC_Generate_Tables_PublicSchema.sql;
--File 2 to Generate the Schema on LAT_MDM_STAGING
@@SFDC_LAT_PublicSchema.sql;
exit 0;